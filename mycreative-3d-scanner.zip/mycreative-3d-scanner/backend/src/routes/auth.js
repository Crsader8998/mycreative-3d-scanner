import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { pool } from '../db.js';
import { clearAuthCookie, requireAuth, setAuthCookie } from '../auth.js';

const router = Router();
const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const publicUser = (row) => ({ id: row.id, name: row.name, email: row.email, createdAt: row.created_at });

router.post('/register', async (req, res, next) => {
  try {
    const name = typeof req.body.name === 'string' ? req.body.name.trim() : '';
    const email = typeof req.body.email === 'string' ? req.body.email.trim().toLowerCase() : '';
    const password = typeof req.body.password === 'string' ? req.body.password : '';
    if (name.length < 2 || name.length > 80) return res.status(400).json({ error: 'Имя должно содержать от 2 до 80 символов' });
    if (email.length > 254 || !emailPattern.test(email)) return res.status(400).json({ error: 'Укажите корректный email' });
    if (password.length < 8 || password.length > 72) return res.status(400).json({ error: 'Пароль должен содержать от 8 до 72 символов' });
    const passwordHash = await bcrypt.hash(password, 12);
    const result = await pool.query(
      'INSERT INTO users(name, email, password_hash) VALUES($1, $2, $3) RETURNING id, name, email, created_at',
      [name, email, passwordHash],
    );
    setAuthCookie(res, result.rows[0].id);
    res.status(201).json({ user: publicUser(result.rows[0]) });
  } catch (error) {
    if (error.code === '23505') return res.status(409).json({ error: 'Пользователь с таким email уже существует' });
    next(error);
  }
});

router.post('/login', async (req, res, next) => {
  try {
    const email = typeof req.body.email === 'string' ? req.body.email.trim().toLowerCase() : '';
    const password = typeof req.body.password === 'string' ? req.body.password : '';
    if (!emailPattern.test(email) || !password) return res.status(400).json({ error: 'Введите email и пароль' });
    const result = await pool.query('SELECT id, name, email, password_hash, created_at FROM users WHERE email = $1', [email]);
    const user = result.rows[0];
    if (!user || !(await bcrypt.compare(password, user.password_hash))) return res.status(401).json({ error: 'Неверный email или пароль' });
    setAuthCookie(res, user.id);
    res.json({ user: publicUser(user) });
  } catch (error) { next(error); }
});

router.post('/logout', (_req, res) => { clearAuthCookie(res); res.json({ message: 'Вы вышли из аккаунта' }); });

router.get('/me', requireAuth, async (req, res, next) => {
  try {
    const result = await pool.query('SELECT id, name, email, created_at FROM users WHERE id = $1', [req.userId]);
    if (!result.rowCount) { clearAuthCookie(res); return res.status(401).json({ error: 'Пользователь не найден' }); }
    res.json({ user: publicUser(result.rows[0]) });
  } catch (error) { next(error); }
});

router.patch('/me', requireAuth, async (req, res, next) => {
  try {
    const name = typeof req.body.name === 'string' ? req.body.name.trim() : '';
    if (name.length < 2 || name.length > 80) return res.status(400).json({ error: 'Имя должно содержать от 2 до 80 символов' });
    const result = await pool.query('UPDATE users SET name = $1, updated_at = NOW() WHERE id = $2 RETURNING id, name, email, created_at', [name, req.userId]);
    if (!result.rowCount) return res.status(404).json({ error: 'Пользователь не найден' });
    res.json({ user: publicUser(result.rows[0]) });
  } catch (error) { next(error); }
});

export default router;
