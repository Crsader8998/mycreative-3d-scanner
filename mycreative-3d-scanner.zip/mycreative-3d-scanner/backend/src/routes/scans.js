import { Router } from 'express';
import multer from 'multer';
import path from 'node:path';
import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import { pool } from '../db.js';
import { requireAuth } from '../auth.js';

const router = Router();
const storageDir = path.resolve(process.cwd(), 'storage');
const allowed = new Set(['obj', 'ply', 'gltf']);
const maxBytes = Math.max(1, Number(process.env.MAX_UPLOAD_MB || 100)) * 1024 * 1024;
const upload = multer({
  storage: multer.diskStorage({
    destination: async (_req, _file, cb) => { try { await fs.mkdir(storageDir, { recursive: true }); cb(null, storageDir); } catch (e) { cb(e); } },
    filename: (_req, file, cb) => cb(null, `${crypto.randomUUID()}.${path.extname(file.originalname).slice(1).toLowerCase()}`),
  }),
  limits: { fileSize: maxBytes, files: 1 },
  fileFilter: (_req, file, cb) => {
    const ext = path.extname(file.originalname).slice(1).toLowerCase();
    if (!allowed.has(ext)) return cb(new Error('Поддерживаются только файлы OBJ, PLY и GLTF'));
    cb(null, true);
  },
});

const serialize = (row) => ({
  id: row.id, name: row.name, format: row.format,
  sizeBytes: Number(row.size_bytes), size: formatSize(Number(row.size_bytes)),
  date: new Date(row.created_at).toISOString().slice(0, 10), createdAt: row.created_at,
});
function formatSize(bytes) { if (bytes < 1024) return `${bytes} B`; if (bytes < 1024 ** 2) return `${(bytes / 1024).toFixed(1)} KB`; return `${(bytes / 1024 ** 2).toFixed(1)} MB`; }
function safeName(value) { return String(value || '').replace(/[\\/:*?"<>|\u0000-\u001f]/g, '-').trim().slice(0, 120) || 'Без названия'; }

router.use(requireAuth);

router.get('/', async (req, res, next) => {
  try {
    const { q = '', format = 'all', sort = 'new' } = req.query;
    if (format !== 'all' && !allowed.has(String(format))) return res.status(400).json({ error: 'Неподдерживаемый формат' });
    const orderBy = sort === 'old' ? 'created_at ASC' : sort === 'name' ? 'name ASC' : 'created_at DESC';
    const result = await pool.query(
      `SELECT id, name, format, size_bytes, created_at FROM scans WHERE user_id = $1 AND ($2 = '' OR name ILIKE '%' || $2 || '%') AND ($3 = 'all' OR format = $3) ORDER BY ${orderBy}`,
      [req.userId, String(q).slice(0, 120), String(format)],
    );
    res.json({ scans: result.rows.map(serialize) });
  } catch (error) { next(error); }
});

router.post('/', upload.single('file'), async (req, res, next) => {
  let filePath = req.file?.path;
  try {
    if (!req.file) return res.status(400).json({ error: 'Прикрепите файл модели в поле file' });
    const format = path.extname(req.file.originalname).slice(1).toLowerCase();
    const name = safeName(req.body.name || path.basename(req.file.originalname, path.extname(req.file.originalname)));
    const result = await pool.query(
      'INSERT INTO scans(user_id, name, format, storage_name, original_name, mime_type, size_bytes) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING id, name, format, size_bytes, created_at',
      [req.userId, name, format, path.basename(filePath), req.file.originalname.slice(0, 255), req.file.mimetype || 'application/octet-stream', req.file.size],
    );
    filePath = null;
    res.status(201).json({ scan: serialize(result.rows[0]) });
  } catch (error) { next(error); }
  finally { if (filePath) await fs.unlink(filePath).catch(() => {}); }
});

router.patch('/:id', async (req, res, next) => {
  try {
    const name = safeName(req.body.name);
    if (!req.body.name || name.length > 120) return res.status(400).json({ error: 'Укажите название до 120 символов' });
    const result = await pool.query('UPDATE scans SET name=$1, updated_at=NOW() WHERE id=$2 AND user_id=$3 RETURNING id,name,format,size_bytes,created_at', [name, req.params.id, req.userId]);
    if (!result.rowCount) return res.status(404).json({ error: 'Скан не найден' });
    res.json({ scan: serialize(result.rows[0]) });
  } catch (error) { next(error); }
});

router.get('/:id/download', async (req, res, next) => {
  try {
    const result = await pool.query('SELECT storage_name, original_name, mime_type FROM scans WHERE id=$1 AND user_id=$2', [req.params.id, req.userId]);
    if (!result.rowCount) return res.status(404).json({ error: 'Скан не найден' });
    const row = result.rows[0];
    const filePath = path.join(storageDir, path.basename(row.storage_name));
    try { await fs.access(filePath); } catch { return res.status(410).json({ error: 'Файл модели отсутствует на сервере' }); }
    res.type(row.mime_type).download(filePath, row.original_name);
  } catch (error) { next(error); }
});

router.delete('/:id', async (req, res, next) => {
  try {
    const result = await pool.query('DELETE FROM scans WHERE id=$1 AND user_id=$2 RETURNING storage_name', [req.params.id, req.userId]);
    if (!result.rowCount) return res.status(404).json({ error: 'Скан не найден' });
    await fs.unlink(path.join(storageDir, path.basename(result.rows[0].storage_name))).catch(() => {});
    res.json({ message: 'Скан удалён' });
  } catch (error) { next(error); }
});

export default router;
