import jwt from 'jsonwebtoken';

const COOKIE_NAME = 'mc_session';
const maxAge = 7 * 24 * 60 * 60 * 1000;

export function setAuthCookie(res, userId) {
  const token = jwt.sign({ sub: userId }, process.env.JWT_SECRET, { expiresIn: '7d', issuer: 'mycreative' });
  res.cookie(COOKIE_NAME, token, {
    httpOnly: true,
    secure: process.env.COOKIE_SECURE === 'true',
    sameSite: 'lax',
    path: '/',
    maxAge,
  });
}

export function clearAuthCookie(res) {
  res.clearCookie(COOKIE_NAME, {
    httpOnly: true,
    secure: process.env.COOKIE_SECURE === 'true',
    sameSite: 'lax',
    path: '/',
  });
}

export function requireAuth(req, res, next) {
  const token = req.cookies?.[COOKIE_NAME];
  if (!token) return res.status(401).json({ error: 'Требуется авторизация' });
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET, { issuer: 'mycreative' });
    req.userId = payload.sub;
    next();
  } catch {
    clearAuthCookie(res);
    return res.status(401).json({ error: 'Сессия истекла. Войдите снова.' });
  }
}
