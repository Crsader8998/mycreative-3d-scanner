import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import cookieParser from 'cookie-parser';
import rateLimit from 'express-rate-limit';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { pool } from './db.js';
import authRoutes from './routes/auth.js';
import scanRoutes from './routes/scans.js';

if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) throw new Error('JWT_SECRET must contain at least 32 characters');
const app = express();
const port = Number(process.env.PORT || 3000);
const rootDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');

app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false }));
app.use(express.json({ limit: '32kb' }));
app.use(express.urlencoded({ extended: false, limit: '32kb' }));
app.use(cookieParser());
app.use('/api/auth', rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: 'draft-7', legacyHeaders: false, message: { error: 'Слишком много запросов. Попробуйте позже.' } }));
app.use('/api/scans', rateLimit({ windowMs: 60 * 1000, limit: 60, standardHeaders: 'draft-7', legacyHeaders: false }));

app.get('/api/health', async (_req, res) => {
  try { await pool.query('SELECT 1'); res.json({ status: 'ok', database: 'connected' }); }
  catch { res.status(503).json({ status: 'error', database: 'unavailable' }); }
});
app.use('/api/auth', authRoutes);
app.use('/api/scans', scanRoutes);
app.use(express.static(rootDir, { extensions: ['html'], index: 'index.html', dotfiles: 'ignore' }));
app.use('/api', (_req, res) => res.status(404).json({ error: 'API-маршрут не найден' }));
app.use((error, _req, res, _next) => {
  if (error?.code === 'LIMIT_FILE_SIZE') return res.status(413).json({ error: `Файл слишком большой. Максимум ${process.env.MAX_UPLOAD_MB || 100} МБ` });
  if (error?.name === 'MulterError') return res.status(400).json({ error: 'Ошибка загрузки файла' });
  if (error?.message?.startsWith('Поддерживаются только')) return res.status(400).json({ error: error.message });
  console.error(error);
  res.status(500).json({ error: 'Внутренняя ошибка сервера' });
});

const server = app.listen(port, () => console.log(`MyCreative server: http://localhost:${port}`));
async function shutdown() { server.close(() => {}); await pool.end(); process.exit(0); }
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
