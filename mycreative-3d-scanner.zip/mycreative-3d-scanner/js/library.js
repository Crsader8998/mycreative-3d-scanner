import { initParticles } from './particles.js';
import { CursorTrail } from './cursor-trail.js';
import { initCursorSettings } from './cursor-settings.js';
import { renderAuthBlock, loadCurrentUser, apiRequest } from './auth.js';

initParticles('particles-bg');
const trail = new CursorTrail('cursor-trail');
initCursorSettings(trail);
await renderAuthBlock('nav-auth');
const user = await loadCurrentUser();
if (!user) location.replace('login.html');

const grid = document.getElementById('library-grid');
const empty = document.getElementById('library-empty');
const count = document.getElementById('library-count');
const searchInput = document.getElementById('library-search');
const formatSelect = document.getElementById('library-format');
const sortSelect = document.getElementById('library-sort');
let scans = [];
let loading = false;

function plural(n, one, few, many) {
  const mod10 = n % 10; const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return one;
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 10 || mod100 >= 20)) return few;
  return many;
}
function formatDate(value) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? 'Дата неизвестна' : date.toLocaleDateString('ru-RU', { day: '2-digit', month: 'long', year: 'numeric' });
}
function getInitials(name) { return name.split(/\s+/).filter(Boolean).map((word) => word[0]).slice(0, 2).join('').toUpperCase(); }

async function loadScans() {
  if (!user || loading) return;
  loading = true;
  try {
    const params = new URLSearchParams({ q: searchInput?.value.trim() || '', format: formatSelect?.value || 'all', sort: sortSelect?.value || 'new' });
    const result = await apiRequest(`/api/scans?${params}`);
    scans = result.scans;
    render();
  } catch (error) {
    grid.replaceChildren();
    empty.hidden = false;
    empty.textContent = error.message || 'Не удалось загрузить библиотеку';
    count.textContent = 'Ошибка загрузки';
  } finally { loading = false; }
}

function render() {
  if (!grid || !empty || !count) return;
  count.textContent = `${scans.length} ${plural(scans.length, 'скан', 'скана', 'сканов')}`;
  grid.replaceChildren();
  empty.hidden = scans.length > 0;
  if (!scans.length) empty.textContent = 'Пока нет сканов. Создайте модель в сканере или загрузите файл.';
  scans.forEach((scan) => grid.append(createScanCard(scan)));
}

function createScanCard(scan) {
  const card = document.createElement('article'); card.className = 'scan-card'; card.dataset.id = scan.id;
  const preview = document.createElement('div'); preview.className = 'scan-card__preview';
  const badge = document.createElement('span'); badge.className = 'scan-card__badge latin'; badge.textContent = `.${scan.format}`;
  const icon = document.createElement('span'); icon.className = 'scan-card__icon'; icon.textContent = getInitials(scan.name);
  preview.append(badge, icon);
  const body = document.createElement('div'); body.className = 'scan-card__body';
  const title = document.createElement('h3'); title.className = 'scan-card__title'; title.textContent = scan.name;
  const meta = document.createElement('div'); meta.className = 'scan-card__meta';
  meta.append(createSpan(formatDate(scan.createdAt || scan.date)), createSpan('·'), createSpan(scan.size || '—'));
  body.append(title, meta);
  const actions = document.createElement('div'); actions.className = 'scan-card__actions';
  const download = document.createElement('button'); download.type = 'button'; download.className = 'btn btn--ghost'; download.dataset.action = 'download'; download.dataset.id = scan.id; download.textContent = 'Скачать';
  const del = document.createElement('button'); del.type = 'button'; del.className = 'scan-card__delete'; del.dataset.action = 'delete'; del.dataset.id = scan.id; del.setAttribute('aria-label', `Удалить скан «${scan.name}»`); del.textContent = 'Удалить';
  actions.append(download, del); card.append(preview, body, actions); return card;
}
function createSpan(text) { const span = document.createElement('span'); span.textContent = text; return span; }

grid?.addEventListener('click', async (event) => {
  const button = event.target.closest('[data-action]');
  if (!button) return;
  const id = button.dataset.id;
  const scan = scans.find((item) => item.id === id);
  if (!scan) return;
  button.disabled = true;
  try {
    if (button.dataset.action === 'download') {
      const response = await fetch(`/api/scans/${encodeURIComponent(id)}/download`, { credentials: 'same-origin' });
      if (!response.ok) { const body = await response.json().catch(() => ({})); throw new Error(body.error || 'Не удалось скачать файл'); }
      const blob = await response.blob();
      const url = URL.createObjectURL(blob); const link = document.createElement('a');
      link.href = url; link.download = `${safeFileName(scan.name)}.${scan.format}`; document.body.append(link); link.click(); link.remove(); URL.revokeObjectURL(url);
    } else if (button.dataset.action === 'delete' && confirm(`Удалить скан «${scan.name}»?`)) {
      await apiRequest(`/api/scans/${encodeURIComponent(id)}`, { method: 'DELETE' });
      scans = scans.filter((item) => item.id !== id); render();
    }
  } catch (error) { alert(error.message); }
  finally { button.disabled = false; }
});
function safeFileName(value) { return value.replace(/[\\/:*?"<>|]+/g, '-').trim() || 'mycreative-scan'; }
let searchTimer;
searchInput?.addEventListener('input', () => { clearTimeout(searchTimer); searchTimer = setTimeout(loadScans, 250); });
formatSelect?.addEventListener('change', loadScans);
sortSelect?.addEventListener('change', loadScans);

const burger = document.getElementById('burger'); const nav = document.getElementById('nav');
burger?.addEventListener('click', () => { if (!nav) return; const open = nav.classList.toggle('is-open'); burger.classList.toggle('is-active', open); burger.setAttribute('aria-expanded', String(open)); burger.setAttribute('aria-label', open ? 'Закрыть меню' : 'Открыть меню'); });
nav?.querySelectorAll('a').forEach((link) => link.addEventListener('click', () => { nav.classList.remove('is-open'); burger?.classList.remove('is-active'); burger?.setAttribute('aria-expanded', 'false'); burger?.setAttribute('aria-label', 'Открыть меню'); }));
await loadScans();
