import { initParticles } from "./particles.js";
import { CursorTrail } from "./cursor-trail.js";
import { initCursorSettings } from "./cursor-settings.js";
import { renderAuthBlock, getCurrentUser } from "./auth.js";

initParticles("particles-bg");
const trail = new CursorTrail("cursor-trail");
initCursorSettings(trail);
renderAuthBlock("nav-auth");

const STORAGE_KEY = "mycreative.scans";
const ALLOWED_FORMATS = new Set(["obj", "ply", "gltf"]);

const DEMO_SCANS = [
  { id: "s1", name: "Бюст Сократа", format: "obj", size: "12.4 MB", date: "2026-09-14" },
  { id: "s2", name: "Шлем рыцаря", format: "gltf", size: "8.1 MB", date: "2026-09-12" },
  { id: "s3", name: "Кубик Рубика", format: "ply", size: "3.7 MB", date: "2026-09-10" },
  { id: "s4", name: "Шахматный конь", format: "obj", size: "5.2 MB", date: "2026-09-07" },
  { id: "s5", name: "Ваза с узором", format: "gltf", size: "6.9 MB", date: "2026-09-05" },
  { id: "s6", name: "Механизм часов", format: "obj", size: "15.3 MB", date: "2026-09-02" },
];

function normalizeScan(scan) {
  if (!scan || typeof scan !== "object") return null;
  const format = String(scan.format || "").toLowerCase();
  if (!ALLOWED_FORMATS.has(format)) return null;
  return {
    id: String(scan.id || ""),
    name: String(scan.name || "Без названия").slice(0, 120),
    format,
    size: String(scan.size || "—").slice(0, 30),
    date: /^\d{4}-\d{2}-\d{2}$/.test(String(scan.date || "")) ? String(scan.date) : new Date().toISOString().slice(0, 10),
  };
}

function loadScans() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed.map(normalizeScan).filter(Boolean);
    }
  } catch {}
  localStorage.setItem(STORAGE_KEY, JSON.stringify(DEMO_SCANS));
  return DEMO_SCANS.map((scan) => ({ ...scan }));
}

function saveScans(items) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
}

const grid = document.getElementById("library-grid");
const empty = document.getElementById("library-empty");
const count = document.getElementById("library-count");
const searchInput = document.getElementById("library-search");
const formatSelect = document.getElementById("library-format");
const sortSelect = document.getElementById("library-sort");
const user = getCurrentUser();
let scans = loadScans();

function plural(n, one, few, many) {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return one;
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 10 || mod100 >= 20)) return few;
  return many;
}

function formatDate(iso) {
  const date = new Date(`${iso}T00:00:00`);
  if (Number.isNaN(date.getTime())) return "Дата неизвестна";
  return date.toLocaleDateString("ru-RU", { day: "2-digit", month: "long", year: "numeric" });
}

function getInitials(name) {
  return name.split(/\s+/).filter(Boolean).map((word) => word[0]).slice(0, 2).join("").toUpperCase();
}

function render() {
  if (!grid || !empty || !count || !searchInput || !formatSelect || !sortSelect) return;

  const query = searchInput.value.trim().toLowerCase();
  const format = formatSelect.value;
  const sort = sortSelect.value;

  const filtered = scans.filter((scan) => {
    if (query && !scan.name.toLowerCase().includes(query)) return false;
    return format === "all" || scan.format === format;
  });

  filtered.sort((a, b) => {
    if (sort === "new") return b.date.localeCompare(a.date);
    if (sort === "old") return a.date.localeCompare(b.date);
    if (sort === "name") return a.name.localeCompare(b.name, "ru");
    return 0;
  });

  count.textContent = `${filtered.length} ${plural(filtered.length, "скан", "скана", "сканов")}`;
  grid.replaceChildren();
  empty.hidden = filtered.length > 0;

  filtered.forEach((scan) => grid.append(createScanCard(scan)));
}

function createScanCard(scan) {
  const card = document.createElement("article");
  card.className = "scan-card";
  card.dataset.id = scan.id;

  const preview = document.createElement("div");
  preview.className = "scan-card__preview";

  const badge = document.createElement("span");
  badge.className = "scan-card__badge latin";
  badge.textContent = `.${scan.format}`;

  const icon = document.createElement("span");
  icon.className = "scan-card__icon";
  icon.textContent = getInitials(scan.name);
  preview.append(badge, icon);

  const body = document.createElement("div");
  body.className = "scan-card__body";
  const title = document.createElement("h3");
  title.className = "scan-card__title";
  title.textContent = scan.name;
  const meta = document.createElement("div");
  meta.className = "scan-card__meta";
  meta.append(createSpan(formatDate(scan.date)), createSpan("·"), createSpan(scan.size));
  body.append(title, meta);

  const actions = document.createElement("div");
  actions.className = "scan-card__actions";
  const download = document.createElement("button");
  download.type = "button";
  download.className = "btn btn--ghost";
  download.dataset.action = "download";
  download.dataset.id = scan.id;
  download.textContent = "Скачать";
  actions.append(download);

  if (user) {
    const del = document.createElement("button");
    del.type = "button";
    del.className = "scan-card__delete";
    del.dataset.action = "delete";
    del.dataset.id = scan.id;
    del.setAttribute("aria-label", `Удалить скан «${scan.name}»`);
    del.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/></svg>';
    actions.append(del);
  }

  card.append(preview, body, actions);
  return card;
}

function createSpan(text) {
  const span = document.createElement("span");
  span.textContent = text;
  return span;
}

grid?.addEventListener("click", (event) => {
  const button = event.target.closest("[data-action]");
  if (!button) return;
  const scan = scans.find((item) => item.id === button.dataset.id);
  if (!scan) return;

  if (button.dataset.action === "download") {
    downloadScan(scan);
    return;
  }

  if (button.dataset.action === "delete" && confirm(`Удалить скан «${scan.name}»?`)) {
    scans = scans.filter((item) => item.id !== scan.id);
    saveScans(scans);
    render();
  }
});

function downloadScan(scan) {
  const content = createDemoModel(scan.format, scan.name);
  const type = scan.format === "gltf" ? "model/gltf+json" : "text/plain;charset=utf-8";
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `${safeFileName(scan.name)}.${scan.format}`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

function createDemoModel(format, name) {
  if (format === "ply") return `ply\nformat ascii 1.0\ncomment MyCreative demo: ${name}\nelement vertex 3\nproperty float x\nproperty float y\nproperty float z\nelement face 1\nproperty list uchar int vertex_indices\nend_header\n0 0 0\n1 0 0\n0 1 0\n3 0 1 2\n`;
  if (format === "gltf") return JSON.stringify({ asset: { version: "2.0", generator: "MyCreative 3D Scanner demo" }, scene: 0, scenes: [{ nodes: [] }] }, null, 2);
  return `# MyCreative 3D Scanner demo: ${name}\no DemoScan\nv 0 0 0\nv 1 0 0\nv 0 1 0\nf 1 2 3\n`;
}

function safeFileName(value) {
  return value.replace(/[\\/:*?"<>|]+/g, "-").trim() || "mycreative-scan";
}

searchInput?.addEventListener("input", render);
formatSelect?.addEventListener("change", render);
sortSelect?.addEventListener("change", render);

const burger = document.getElementById("burger");
const nav = document.getElementById("nav");
burger?.addEventListener("click", () => {
  if (!nav) return;
  const open = nav.classList.toggle("is-open");
  burger.classList.toggle("is-active", open);
  burger.setAttribute("aria-expanded", String(open));
  burger.setAttribute("aria-label", open ? "Закрыть меню" : "Открыть меню");
});

nav?.querySelectorAll("a").forEach((link) => link.addEventListener("click", () => {
  nav.classList.remove("is-open");
  burger?.classList.remove("is-active");
  burger?.setAttribute("aria-expanded", "false");
  burger?.setAttribute("aria-label", "Открыть меню");
}));

render();
