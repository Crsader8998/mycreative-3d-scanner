import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";

export function createScene(container, options = {}) {
  const {
    enableControls = false,
    autoRotate = true,
    cameraZ = 5,
    onFps = null,
  } = options;
  const renderer = new THREE.WebGLRenderer({
    antialias: true,
    alpha: true,
    powerPreference: "high-performance",
  });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(container.clientWidth, container.clientHeight);
  renderer.setClearColor(0x000000, 0);
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.1;
  container.appendChild(renderer.domElement);
  const scene = new THREE.Scene();
  scene.fog = new THREE.FogExp2(0x0a0a0a, 0.06);
  const camera = new THREE.PerspectiveCamera(
    45,
    container.clientWidth / container.clientHeight,
    0.1,
    100
  );
  camera.position.set(0, 0, cameraZ);
  let controls = null;
  if (enableControls) {
    controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.enablePan = false;
    controls.minDistance = 3;
    controls.maxDistance = 10;
    controls.autoRotate = autoRotate;
    controls.autoRotateSpeed = 0.8;
  }
  const hemi = new THREE.HemisphereLight(0xaaccff, 0x1a1a1a, 0.6);
  scene.add(hemi);

  const keyLight = new THREE.PointLight(0xff6b4a, 8, 20);
  keyLight.position.set(3, 3, 4);
  scene.add(keyLight);

  const rimLight = new THREE.PointLight(0x4caf50, 6, 20);
  rimLight.position.set(-4, -2, -3);
  scene.add(rimLight);

  const bottomLight = new THREE.PointLight(0x72281c, 5, 15);
  bottomLight.position.set(0, -3, 2);
  scene.add(bottomLight);
  const geo = new THREE.IcosahedronGeometry(1.3, 2);

  const mat = new THREE.MeshStandardMaterial({
    color: 0x2c5626,
    metalness: 0.65,
    roughness: 0.35,
    emissive: 0x0d1a0b,
    emissiveIntensity: 0.6,
    flatShading: true,
    transparent: true,
    opacity: 0.92,
  });
  const mesh = new THREE.Mesh(geo, mat);
  scene.add(mesh);

  const wireMat = new THREE.MeshBasicMaterial({
    color: 0x7fd166,
    wireframe: true,
    transparent: true,
    opacity: 0.28,
  });
  const wire = new THREE.Mesh(geo, wireMat);
  wire.scale.setScalar(1.005);
  scene.add(wire);

  const coreGeo = new THREE.SphereGeometry(0.12, 16, 16);
  const coreMat = new THREE.MeshBasicMaterial({ color: 0xff6b4a });
  const core = new THREE.Mesh(coreGeo, coreMat);
  scene.add(core);
  const particleCount = 420;
  const positions = new Float32Array(particleCount * 3);
  for (let i = 0; i < particleCount; i++) {
    const r = 2.2 + Math.random() * 2.5;
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.acos(2 * Math.random() - 1);
    positions[i * 3]     = r * Math.sin(phi) * Math.cos(theta);
    positions[i * 3 + 1] = r * Math.cos(phi) * 0.7;
    positions[i * 3 + 2] = r * Math.sin(phi) * Math.sin(theta);
  }
  const pGeo = new THREE.BufferGeometry();
  pGeo.setAttribute("position", new THREE.BufferAttribute(positions, 3));
  const pMat = new THREE.PointsMaterial({
    color: 0x7fd166,
    size: 0.035,
    transparent: true,
    opacity: 0.85,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
  });
  const points = new THREE.Points(pGeo, pMat);
  scene.add(points);
  const laserGroup = new THREE.Group();
  const laserColor = 0xff5a3c;
  const laserCount = 8;
  const lasers = [];

  for (let i = 0; i < laserCount; i++) {
    const angle = (i / laserCount) * Math.PI * 2;
    const radius = 2.2;
    const x = Math.cos(angle) * radius;
    const z = Math.sin(angle) * radius;

    const geoL = new THREE.BufferGeometry().setFromPoints([
      new THREE.Vector3(x, -3, z),
      new THREE.Vector3(0, 0, 0),
    ]);
    const matL = new THREE.LineBasicMaterial({
      color: laserColor,
      transparent: true,
      opacity: 0.55,
      blending: THREE.AdditiveBlending,
    });
    const line = new THREE.Line(geoL, matL);
    laserGroup.add(line);
    lasers.push(line);
  }
  scene.add(laserGroup);
  function resize() {
    const w = container.clientWidth;
    const h = container.clientHeight;
    if (!w || !h) return;
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    renderer.setSize(w, h);
  }
  const ro = new ResizeObserver(resize);
  ro.observe(container);
  const clock = new THREE.Clock();
  let frames = 0;
  let lastFpsTime = performance.now();
  let raf;

  function animate() {
    raf = requestAnimationFrame(animate);

    const t = clock.getElapsedTime();

    // Вращение
    mesh.rotation.y += 0.0035;
    mesh.rotation.x = Math.sin(t * 0.4) * 0.15;

    wire.rotation.copy(mesh.rotation);
    core.scale.setScalar(1 + Math.sin(t * 3) * 0.15);

    // Частицы вращаются в противоположную сторону
    points.rotation.y -= 0.0012;
    points.rotation.x += 0.0006;

    // Лазеры пульсируют
    lasers.forEach((line, i) => {
      line.material.opacity = 0.35 + Math.sin(t * 2 + i * 0.7) * 0.35;
    });

    // Свет двигается
    keyLight.position.x = Math.sin(t * 0.6) * 4;
    keyLight.position.z = Math.cos(t * 0.6) * 4;
    rimLight.position.x = Math.sin(t * 0.4 + Math.PI) * 5;
    rimLight.position.z = Math.cos(t * 0.4 + Math.PI) * 5;

    if (controls) controls.update();

    renderer.render(scene, camera);

    // FPS
    frames++;
    const now = performance.now();
    if (now - lastFpsTime >= 1000) {
      if (onFps) onFps(frames);
      frames = 0;
      lastFpsTime = now;
    }
  }

  animate();
  return {
    scene,
    camera,
    renderer,
    mesh,
    wire,
    points,
    laserGroup,
    controls,
    startScanAnimation(onProgress) {
      const startTime = performance.now();
      const duration = 3000;
      const originalPositions = positions.slice();

      return new Promise((resolve) => {
        function step() {
          const elapsed = performance.now() - startTime;
          const p = Math.min(elapsed / duration, 1);
          const eased = 1 - Math.pow(1 - p, 3);

          const pos = pGeo.attributes.position.array;
        for (let i = 0; i < particleCount; i++) {
          const ix = i * 3;
          pos[ix]     = originalPositions[ix]     * (1 - eased * 0.8);
          pos[ix + 1] = originalPositions[ix + 1] * (1 - eased * 0.8);
          pos[ix + 2] = originalPositions[ix + 2] * (1 - eased * 0.8);
        }
        pGeo.attributes.position.needsUpdate = true;

          mesh.rotation.y += 0.02;
          wire.rotation.y = mesh.rotation.y;
          mat.emissiveIntensity = 0.6 + p * 2.5;

          if (onProgress) onProgress(p);

          if (p < 1) {
            requestAnimationFrame(step);
          } else {
            for (let i = 0; i < particleCount * 3; i++) {
              pGeo.attributes.position.array[i] = originalPositions[i];
            }
            pGeo.attributes.position.needsUpdate = true;
            mat.emissiveIntensity = 0.6;
            resolve();
          }
        }
        step();
      });
    },
    dispose() {
      cancelAnimationFrame(raf);
      ro.disconnect();
      controls?.dispose();
      renderer.dispose();
      geo.dispose();
      mat.dispose();
      wireMat.dispose();
      coreGeo.dispose();
      coreMat.dispose();
      pGeo.dispose();
      pMat.dispose();
      lasers.forEach((line) => {
        line.geometry.dispose();
        line.material.dispose();
      });
      renderer.domElement.remove();
    },
  };
}