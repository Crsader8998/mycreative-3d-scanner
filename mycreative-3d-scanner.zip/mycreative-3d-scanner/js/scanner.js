import { createScene } from "./three-scene.js";
import { initParticles } from "./particles.js";
import { CursorTrail } from "./cursor-trail.js";
import { initCursorSettings } from "./cursor-settings.js";
import { attachWatermark } from "./watermark.js";
import { renderAuthBlock } from "./auth.js";

initParticles("particles-bg");

const trail = new CursorTrail("cursor-trail");
initCursorSettings(trail);

renderAuthBlock("nav-auth");
const viewport    = document.getElementById("viewport");
const btnScan     = document.getElementById("btn-scan");
const btnText     = document.getElementById("btn-scan-text");
const btnDown     = document.getElementById("btn-download");
const btnAgain    = document.getElementById("btn-again");
const progressBar = document.getElementById("progress-bar");
const progressLbl = document.getElementById("progress-label");
const statusBadge = document.getElementById("status-badge-text");
const hudFps      = document.getElementById("hud-fps");
const hudState    = document.getElementById("hud-state");
const resultCard  = document.getElementById("scan-result");
const formatSel   = document.getElementById("format");
const sceneApi = createScene(viewport, {
  enableControls: true,
  autoRotate: true,
  cameraZ: 5,
  onFps: (fps) => {
    if (hudFps) hudFps.textContent = `${fps} FPS`;
  },
});

attachWatermark(viewport, {
  text: "© MyCreative 3D Scanner",
  subtext: "mycreative.ru · 2026",
  logo: "assets/logo.svg",
  position: "br",
  opacity: 0.4,
  dense: false,
});
let isScanning = false;

function setState(state) {
  if (hudState) hudState.textContent = state;
  if (statusBadge) {
    statusBadge.textContent =
      state === "SCANNING" ? "Сканирование" :
      state === "DONE"     ? "Готово" :
                             "Готов";
  }
}

function setProgress(value, label) {
  if (progressBar) progressBar.style.width = `${value}%`;
  if (label && progressLbl) progressLbl.textContent = label;
}

async function runScan() {
  if (isScanning) return;
  isScanning = true;

  btnScan.disabled = true;
  if (btnText) btnText.textContent = "Сканирование...";
  if (viewport) viewport.classList.add("is-scanning");
  if (resultCard) resultCard.classList.remove("is-visible");

  setState("SCANNING");
  setProgress(0, "Инициализация...");

  await sceneApi.startScanAnimation((p) => {
    const percent = Math.round(p * 100);
    setProgress(percent, `Сканирование... ${percent}%`);
  });

  if (viewport) viewport.classList.remove("is-scanning");
  setProgress(100, "Готово!");
  setState("DONE");
  if (btnText) btnText.textContent = "Сканировать снова";
  btnScan.disabled = false;
  isScanning = false;

  if (resultCard) {
    resultCard.hidden = false;
    requestAnimationFrame(() => resultCard.classList.add("is-visible"));
  }
}

function downloadResult() {
  const format = formatSel?.value || "obj";
  const content = createDemoModel(format);
  const type = format === "gltf" ? "model/gltf+json" : "text/plain;charset=utf-8";
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `mycreative-scan-${Date.now()}.${format}`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

function createDemoModel(format) {
  if (format === "ply") {
    return "ply\nformat ascii 1.0\ncomment MyCreative 3D Scanner demo\nelement vertex 3\nproperty float x\nproperty float y\nproperty float z\nelement face 1\nproperty list uchar int vertex_indices\nend_header\n0 0 0\n1 0 0\n0 1 0\n3 0 1 2\n";
  }
  if (format === "gltf") {
    return JSON.stringify({ asset: { version: "2.0", generator: "MyCreative 3D Scanner demo" }, scene: 0, scenes: [{ nodes: [] }] }, null, 2);
  }
  return "# MyCreative 3D Scanner demo\no DemoScan\nv 0 0 0\nv 1 0 0\nv 0 1 0\nf 1 2 3\n";
}

btnScan?.addEventListener("click", runScan);
btnDown?.addEventListener("click", downloadResult);
btnAgain?.addEventListener("click", () => {
  if (!resultCard) return;
  resultCard.classList.remove("is-visible");
  setTimeout(() => {
    resultCard.hidden = true;
    setProgress(0, "Готов к сканированию");
    setState("IDLE");
    if (btnText) btnText.textContent = "Начать сканирование";
  }, 300);
});

const burger = document.getElementById("burger");
const nav = document.getElementById("nav");

burger?.addEventListener("click", () => {
  if (!nav) return;
  const isOpen = nav.classList.toggle("is-open");
  burger.classList.toggle("is-active", isOpen);
  burger.setAttribute("aria-expanded", String(isOpen));
  burger.setAttribute("aria-label", isOpen ? "Закрыть меню" : "Открыть меню");
});
nav?.querySelectorAll("a").forEach((link) => link.addEventListener("click", () => {
  nav.classList.remove("is-open");
  burger?.classList.remove("is-active");
  burger?.setAttribute("aria-expanded", "false");
  burger?.setAttribute("aria-label", "Открыть меню");
}));
