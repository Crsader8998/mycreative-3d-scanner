export class CursorTrail {
  constructor(canvasId = "cursor-trail", options = {}) {
    this.canvas = document.getElementById(canvasId);
    if (!this.canvas) return;

    this.ctx = this.canvas.getContext("2d");
    this.dpr = Math.min(window.devicePixelRatio || 1, 2);

    this.color = options.color || "#7fd166";
    this.size = options.size || 9;
    this.enabled = options.enabled !== false;
    this.maxPoints = 40;
    this.fadeSpeed = 0.045;

    this.points = [];
    this.mouse = { x: -100, y: -100, moved: false };
    this.raf = null;

    this._resize = this._resize.bind(this);
    this._onMove = this._onMove.bind(this);
    this._onLeave = this._onLeave.bind(this);
    this._render = this._render.bind(this);

    this._init();
  }

  _init() {
    this._resize();
    window.addEventListener("resize", this._resize);
    window.addEventListener("mousemove", this._onMove, { passive: true });
    window.addEventListener("mouseleave", this._onLeave);
    document.addEventListener("touchstart", this._onMove, { passive: true });
    document.addEventListener("touchmove", this._onMove, { passive: true });
    this._render();
  }

  _resize() {
    this.width = window.innerWidth;
    this.height = window.innerHeight;
    this.canvas.width = this.width * this.dpr;
    this.canvas.height = this.height * this.dpr;
    this.canvas.style.width = this.width + "px";
    this.canvas.style.height = this.height + "px";
    this.ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
  }

  _onMove(e) {
    const point = e.touches ? e.touches[0] : e;
    if (!point) return;
    this.mouse.x = point.clientX;
    this.mouse.y = point.clientY;
    this.mouse.moved = true;
  }

  _onLeave() {
    this.mouse.moved = false;
  }

  _render() {
    this.raf = requestAnimationFrame(this._render);

    if (!this.enabled) {
      this.ctx.clearRect(0, 0, this.width, this.height);
      return;
    }

    if (this.mouse.moved) {
      this.points.push({ x: this.mouse.x, y: this.mouse.y, life: 1 });
      if (this.points.length > this.maxPoints) this.points.shift();
    }

    this.ctx.clearRect(0, 0, this.width, this.height);

    for (const p of this.points) p.life -= this.fadeSpeed;
    this.points = this.points.filter((p) => p.life > 0);

    if (this.points.length < 2) return;

    const rgb = this._hexToRgb(this.color);

    for (let i = 1; i < this.points.length; i++) {
      const a = this.points[i - 1];
      const b = this.points[i];
      const alpha = b.life * 0.75;
      const width = this.size * b.life;

      this.ctx.beginPath();
      this.ctx.lineCap = "round";
      this.ctx.lineJoin = "round";
      this.ctx.strokeStyle = `rgba(${rgb.r},${rgb.g},${rgb.b},${alpha})`;
      this.ctx.lineWidth = width;
      this.ctx.moveTo(a.x, a.y);
      this.ctx.lineTo(b.x, b.y);
      this.ctx.stroke();
    }

    if (this.mouse.moved) {
      const head = this.points[this.points.length - 1];
      const gradient = this.ctx.createRadialGradient(
        head.x, head.y, 0,
        head.x, head.y, this.size * 4
      );
      gradient.addColorStop(0, `rgba(${rgb.r},${rgb.g},${rgb.b},0.35)`);
      gradient.addColorStop(1, `rgba(${rgb.r},${rgb.g},${rgb.b},0)`);
      this.ctx.fillStyle = gradient;
      this.ctx.beginPath();
      this.ctx.arc(head.x, head.y, this.size * 4, 0, Math.PI * 2);
      this.ctx.fill();
    }
  }

  _hexToRgb(hex) {
    const h = hex.replace("#", "");
    const bigint = parseInt(h, 16);
    return {
      r: (bigint >> 16) & 255,
      g: (bigint >> 8) & 255,
      b: bigint & 255,
    };
  }

  setColor(hex) { this.color = hex; }
  setSize(size) { this.size = Number(size); }
  setEnabled(bool) {
    this.enabled = !!bool;
    if (!this.enabled) {
      this.points = [];
      this.mouse.moved = false;
      this.ctx?.clearRect(0, 0, this.width || 0, this.height || 0);
    }
  }

  destroy() {
    cancelAnimationFrame(this.raf);
    window.removeEventListener("resize", this._resize);
    window.removeEventListener("mousemove", this._onMove);
    window.removeEventListener("mouseleave", this._onLeave);
    document.removeEventListener("touchstart", this._onMove);
    document.removeEventListener("touchmove", this._onMove);
  }
}