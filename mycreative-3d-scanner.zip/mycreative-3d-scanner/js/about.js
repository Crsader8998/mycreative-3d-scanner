import { initParticles } from "./particles.js";
import { CursorTrail } from "./cursor-trail.js";
import { initCursorSettings } from "./cursor-settings.js";
import { renderAuthBlock } from "./auth.js";

initParticles("particles-bg");

const trail = new CursorTrail("cursor-trail");
initCursorSettings(trail);

renderAuthBlock("nav-auth");

const burger = document.getElementById("burger");
const nav = document.getElementById("nav");
burger?.addEventListener("click", () => {
  if (!nav) return;
  const isOpen = nav.classList.toggle("is-open");
  burger.classList.toggle("is-active", isOpen);
  burger.setAttribute("aria-expanded", String(isOpen));
  burger.setAttribute("aria-label", isOpen ? "Закрыть меню" : "Открыть меню");
});

const io = new IntersectionObserver(
  (entries) => {
    entries.forEach((e) => {
      if (e.isIntersecting) {
        e.target.classList.add("is-visible");
        io.unobserve(e.target);
      }
    });
  },
  { threshold: 0.15 }
);
document.querySelectorAll(".reveal").forEach((el) => io.observe(el));