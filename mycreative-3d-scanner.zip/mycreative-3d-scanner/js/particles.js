export function initParticles(canvasId = "particles-bg") {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return null;

  const ctx = canvas.getContext("2d");
  let width, height, dpr;
  let particles = [];
  let raf;
  let running = false;

  const COUNT_DESKTOP = 130;
  const COUNT_MOBILE  = 50;
  const MOUSE_RADIUS  = 160;
  const MOUSE_RADIUS_SQ = MOUSE_RADIUS * MOUSE_RADIUS;
  const LINK_DIST = 130;
  const LINK_DIST_SQ = LINK_DIST * LINK_DIST;

  const mouse = { x: -9999, y: -9999 };

  function resize() {
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    width  = window.innerWidth;
    height = window.innerHeight;
    canvas.width  = width  * dpr;
    canvas.height = height * dpr;
    canvas.style.width  = width  + "px";
    canvas.style.height = height + "px";
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    createParticles();
  }

  function createParticles() {
    const count = width < 768 ? COUNT_MOBILE : COUNT_DESKTOP;
    particles = [];
    for (let i = 0; i < count; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        r: Math.random() * 1.8 + 0.5,
        vx: (Math.random() - 0.5) * 0.25,
        vy: (Math.random() - 0.5) * 0.25,
        alpha: Math.random() * 0.5 + 0.2,
        color: Math.random() > 0.5 ? "44,86,38" : "114,40,28",
      });
    }
  }

  function tick() {
    if (!running) return;
    raf = requestAnimationFrame(tick);
    ctx.clearRect(0, 0, width, height);

    for (const p of particles) {
      const dx = p.x - mouse.x;
      const dy = p.y - mouse.y;
      const distSq = dx * dx + dy * dy;

      if (distSq < MOUSE_RADIUS_SQ && distSq > 0) {
        const dist = Math.sqrt(distSq);
        const force = (1 - dist / MOUSE_RADIUS) * 0.6;
        p.x += (dx / dist) * force;
        p.y += (dy / dist) * force;
      }

      p.x += p.vx;
      p.y += p.vy;

      if (p.x < -10) p.x = width + 10;
      if (p.x > width + 10) p.x = -10;
      if (p.y < -10) p.y = height + 10;
      if (p.y > height + 10) p.y = -10;

      const mdx = p.x - mouse.x;
      const mdy = p.y - mouse.y;
      const mdSq = mdx * mdx + mdy * mdy;
      const glow = mdSq < MOUSE_RADIUS_SQ
        ? 1 - Math.sqrt(mdSq) / MOUSE_RADIUS
        : 0;

      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r + glow * 0.8, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(${p.color},${p.alpha + glow * 0.4})`;
      if (glow > 0.3) {
        ctx.shadowColor = `rgba(${p.color},${glow})`;
        ctx.shadowBlur = 12;
      } else {
        ctx.shadowBlur = 0;
      }
      ctx.fill();
      ctx.shadowBlur = 0;
    }

    for (let i = 0; i < particles.length; i++) {
      const a = particles[i];
      for (let j = i + 1; j < particles.length; j++) {
        const b = particles[j];
        const dx = a.x - b.x;
        const dy = a.y - b.y;
        const distSq = dx * dx + dy * dy;

        if (distSq < LINK_DIST_SQ) {
          const dist = Math.sqrt(distSq);
          const opacity = (1 - dist / LINK_DIST) * 0.09;
          ctx.beginPath();
          ctx.strokeStyle = `rgba(140,160,140,${opacity})`;
          ctx.lineWidth = 1;
          ctx.moveTo(a.x, a.y);
          ctx.lineTo(b.x, b.y);
          ctx.stroke();
        }
      }
    }
  }

  function onMouseMove(e) {
    mouse.x = e.clientX;
    mouse.y = e.clientY;
  }
  function onMouseLeave() {
    mouse.x = -9999;
    mouse.y = -9999;
  }

  window.addEventListener("resize", resize);
  window.addEventListener("mousemove", onMouseMove, { passive: true });
  window.addEventListener("mouseleave", onMouseLeave);

  resize();
  running = true;
  tick();

  function onVisibilityChange() {
    if (document.hidden) {
      running = false;
      cancelAnimationFrame(raf);
    } else if (!running) {
      running = true;
      tick();
    }
  }

  document.addEventListener("visibilitychange", onVisibilityChange);

  return {
    destroy() {
      running = false;
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
      window.removeEventListener("mousemove", onMouseMove);
      window.removeEventListener("mouseleave", onMouseLeave);
      document.removeEventListener("visibilitychange", onVisibilityChange);
      ctx.clearRect(0, 0, width, height);
    },
  };
}