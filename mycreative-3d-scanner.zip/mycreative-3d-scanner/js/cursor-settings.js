const STORAGE_KEY = "mycreative.cursor";

export function initCursorSettings(trail) {
  const panel = document.getElementById("cursor-panel");
  const toggle = document.getElementById("cursor-panel-toggle");
  const body = document.getElementById("cursor-panel-body");
  const enabled = document.getElementById("cursor-enabled");
  const colors = document.getElementById("cursor-colors");
  const custom = document.getElementById("cursor-custom");
  const sizeInput = document.getElementById("cursor-size");

  if (!panel || !trail) return;

  markActiveSwatch(colors, trail.color);

  const saved = loadSettings();
  if (saved) {
    trail.setEnabled(saved.enabled);
    trail.setColor(saved.color);
    trail.setSize(saved.size);
    if (enabled) enabled.checked = saved.enabled;
    if (custom) custom.value = saved.color;
    if (sizeInput) sizeInput.value = saved.size;
    markActiveSwatch(colors, saved.color);
  }

  toggle?.addEventListener("click", () => {
    const isOpen = !body.hidden;
    body.hidden = isOpen;
    panel.classList.toggle("is-open", !isOpen);
    toggle.setAttribute("aria-expanded", String(!isOpen));
  });

  enabled?.addEventListener("change", (e) => {
    trail.setEnabled(e.target.checked);
    persist();
  });

  colors?.addEventListener("click", (e) => {
    const swatch = e.target.closest(".swatch");
    if (!swatch) return;
    const color = swatch.dataset.color;
    trail.setColor(color);
    if (custom) custom.value = color;
    markActiveSwatch(colors, color);
    persist();
  });

  custom?.addEventListener("input", (e) => {
    trail.setColor(e.target.value);
    markActiveSwatch(colors, e.target.value);
    persist();
  });

  sizeInput?.addEventListener("input", (e) => {
    trail.setSize(e.target.value);
    persist();
  });


  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && body && !body.hidden) closePanel();
  });

  document.addEventListener("click", (event) => {
    if (body && !body.hidden && !panel.contains(event.target)) closePanel();
  });

  function closePanel() {
    if (!body || !toggle) return;
    body.hidden = true;
    panel.classList.remove("is-open");
    toggle.setAttribute("aria-expanded", "false");
  }

  function persist() {
    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify({
        enabled: enabled?.checked ?? true,
        color: trail.color,
        size: trail.size,
      })
    );
  }
}

function loadSettings() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function markActiveSwatch(container, color) {
  if (!container) return;
  const target = String(color).toLowerCase();
  container.querySelectorAll(".swatch").forEach((sw) => {
    sw.classList.toggle(
      "is-active",
      sw.dataset.color.toLowerCase() === target
    );
  });
}