const USERS_KEY = "mycreative.users";
const SESSION_KEY = "mycreative.session";

export function getUsers() {
  try {
    const users = JSON.parse(localStorage.getItem(USERS_KEY) || "[]");
    return Array.isArray(users) ? users : [];
  } catch {
    return [];
  }
}

export function saveUsers(users) {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

export function register({ name, email, password }) {
  const cleanName = String(name || "").trim();
  const cleanEmail = String(email || "").trim().toLowerCase();
  const users = getUsers();

  if (users.some((user) => String(user.email).toLowerCase() === cleanEmail)) {
    throw new Error("Пользователь с таким email уже существует");
  }

  const user = {
    id: `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`,
    name: cleanName,
    email: cleanEmail,
    password,
    createdAt: new Date().toISOString(),
  };

  users.push(user);
  saveUsers(users);
  setSession(user);
  return user;
}

export function login({ email, password }) {
  const cleanEmail = String(email || "").trim().toLowerCase();
  const user = getUsers().find(
    (item) => String(item.email).toLowerCase() === cleanEmail && item.password === password
  );

  if (!user) throw new Error("Неверный email или пароль");
  setSession(user);
  return user;
}

export function logout() {
  localStorage.removeItem(SESSION_KEY);
}

export function getCurrentUser() {
  try {
    const user = JSON.parse(localStorage.getItem(SESSION_KEY) || "null");
    return user && typeof user === "object" ? user : null;
  } catch {
    return null;
  }
}

export function setSession(user) {
  const { password, ...safeUser } = user;
  localStorage.setItem(SESSION_KEY, JSON.stringify(safeUser));
}

export function renderAuthBlock(containerId = "nav-auth") {
  const container = document.getElementById(containerId);
  if (!container) return;

  container.replaceChildren();
  const user = getCurrentUser();
  const isScanner = document.body.dataset.page === "scanner";

  if (!user) {
    container.append(createLink("login.html", "Войти", "btn btn--ghost btn--sm"));
    if (!isScanner) container.append(createLink("scanner.html", "Сканер", "btn btn--primary btn--sm"));
    return;
  }

  const name = String(user.name || "Пользователь").trim() || "Пользователь";
  const firstName = name.split(/\s+/)[0];
  const initials = name
    .split(/\s+/)
    .filter(Boolean)
    .map((word) => word[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

  const profile = createLink("library.html", "", "nav__user");
  profile.title = name;

  const avatar = document.createElement("span");
  avatar.className = "nav__avatar";
  avatar.textContent = initials;

  const label = document.createElement("span");
  label.textContent = firstName;
  profile.append(avatar, label);

  const logoutButton = document.createElement("button");
  logoutButton.type = "button";
  logoutButton.className = "nav__logout";
  logoutButton.textContent = "Выйти";
  logoutButton.addEventListener("click", () => {
    logout();
    location.reload();
  });

  container.append(profile, logoutButton);
  if (!isScanner) container.append(createLink("scanner.html", "Сканер", "btn btn--primary btn--sm"));
}

function createLink(href, text, className) {
  const link = document.createElement("a");
  link.href = href;
  link.className = className;
  link.textContent = text;
  return link;
}
