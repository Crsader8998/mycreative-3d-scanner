let currentUser = null;
let authLoaded = false;

export async function apiRequest(url, options = {}) {
  const headers = new Headers(options.headers || {});
  if (options.body && !(options.body instanceof FormData) && !headers.has('Content-Type')) headers.set('Content-Type', 'application/json');
  const response = await fetch(url, { ...options, headers, credentials: 'same-origin' });
  const type = response.headers.get('content-type') || '';
  const payload = type.includes('application/json') ? await response.json() : null;
  if (!response.ok) throw new Error(payload?.error || `Ошибка запроса (${response.status})`);
  return payload;
}

export async function register({ name, email, password }) {
  const result = await apiRequest('/api/auth/register', { method: 'POST', body: JSON.stringify({ name, email, password }) });
  currentUser = result.user;
  authLoaded = true;
  return currentUser;
}

export async function login({ email, password }) {
  const result = await apiRequest('/api/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) });
  currentUser = result.user;
  authLoaded = true;
  return currentUser;
}

export async function logout() {
  try { await apiRequest('/api/auth/logout', { method: 'POST' }); }
  finally { currentUser = null; authLoaded = true; }
}

export async function loadCurrentUser() {
  try {
    const result = await apiRequest('/api/auth/me');
    currentUser = result.user;
  } catch {
    currentUser = null;
  }
  authLoaded = true;
  return currentUser;
}

export function getCurrentUser() { return currentUser; }

export async function renderAuthBlock(containerId = 'nav-auth') {
  const container = document.getElementById(containerId);
  if (!container) return;
  if (!authLoaded) await loadCurrentUser();
  container.replaceChildren();
  const user = currentUser;
  const isScanner = document.body.dataset.page === 'scanner';
  if (!user) {
    container.append(createLink('login.html', 'Войти', 'btn btn--ghost btn--sm'));
    if (!isScanner) container.append(createLink('scanner.html', 'Сканер', 'btn btn--primary btn--sm'));
    return;
  }
  const name = String(user.name || 'Пользователь').trim() || 'Пользователь';
  const profile = createLink('library.html', '', 'nav__user');
  profile.title = name;
  const avatar = document.createElement('span');
  avatar.className = 'nav__avatar';
  avatar.textContent = name.split(/\s+/).filter(Boolean).map((word) => word[0]).slice(0, 2).join('').toUpperCase();
  const label = document.createElement('span');
  label.textContent = name.split(/\s+/)[0];
  profile.append(avatar, label);
  const logoutButton = document.createElement('button');
  logoutButton.type = 'button';
  logoutButton.className = 'nav__logout';
  logoutButton.textContent = 'Выйти';
  logoutButton.addEventListener('click', async () => {
    logoutButton.disabled = true;
    try { await logout(); location.href = 'index.html'; }
    catch { logoutButton.disabled = false; }
  });
  container.append(profile, logoutButton);
  if (!isScanner) container.append(createLink('scanner.html', 'Сканер', 'btn btn--primary btn--sm'));
}

function createLink(href, text, className) {
  const link = document.createElement('a');
  link.href = href;
  link.className = className;
  link.textContent = text;
  return link;
}
