export function attachWatermark(container, options = {}) {
  if (!container) return null;

  const {
    text = "© MyCreative 3D Scanner · 2026",
    subtext = "mycreative.ru · github.com/Crsader8998",
    logo = "assets/logo.svg",
    position = "br",
    opacity = 0.35,
    dense = false,
  } = options;

  const wm = document.createElement("div");
  wm.className = `watermark watermark--${position}`;
  wm.setAttribute("aria-hidden", "true");
  wm.style.setProperty("--wm-opacity", opacity);

  wm.innerHTML = `
    <img src="${logo}" alt="" class="watermark__logo" />
    <div class="watermark__text">
      <span class="watermark__main latin">${text}</span>
      <span class="watermark__sub latin">${subtext}</span>
    </div>
  `;

  container.appendChild(wm);

  if (dense) {
    const tile = document.createElement("div");
    tile.className = "watermark-tile";
    tile.setAttribute("aria-hidden", "true");
    tile.style.setProperty("--wm-opacity", opacity * 0.4);
    tile.textContent = text;
    container.appendChild(tile);
  }

  return wm;
}