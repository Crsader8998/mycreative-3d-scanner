import { initParticles } from "./particles.js";
import { CursorTrail } from "./cursor-trail.js";
import { initCursorSettings } from "./cursor-settings.js";
import { login, register, getCurrentUser } from "./auth.js";

initParticles("particles-bg");
const trail = new CursorTrail("cursor-trail");
initCursorSettings(trail);

if (getCurrentUser()) location.replace("library.html");

const tabs = [...document.querySelectorAll(".auth__tab")];
const forms = [...document.querySelectorAll(".auth__form")];

function activateTab(name, focusTab = false) {
  tabs.forEach((tab) => {
    const active = tab.dataset.tab === name;
    tab.classList.toggle("is-active", active);
    tab.setAttribute("aria-selected", String(active));
    tab.tabIndex = active ? 0 : -1;
    if (active && focusTab) tab.focus();
  });

  forms.forEach((form) => {
    const active = form.dataset.form === name;
    form.classList.toggle("is-active", active);
    form.hidden = !active;
  });
}

tabs.forEach((tab, index) => {
  tab.addEventListener("click", () => activateTab(tab.dataset.tab));
  tab.addEventListener("keydown", (event) => {
    if (!["ArrowLeft", "ArrowRight"].includes(event.key)) return;
    event.preventDefault();
    const nextIndex = event.key === "ArrowRight"
      ? (index + 1) % tabs.length
      : (index - 1 + tabs.length) % tabs.length;
    activateTab(tabs[nextIndex].dataset.tab, true);
  });
});

document.querySelectorAll("[data-switch]").forEach((button) => {
  button.addEventListener("click", () => activateTab(button.dataset.switch, true));
});

function showError(form, message = "") {
  const error = form.querySelector("[data-error]");
  if (!error) return;
  error.textContent = message;
  error.hidden = !message;
}

function markInvalid(form, name, invalid) {
  const input = form.querySelector(`[name="${name}"]`);
  if (!input) return;
  input.classList.toggle("is-invalid", invalid);
  input.setAttribute("aria-invalid", String(invalid));
}

forms.forEach((form) => {
  form.addEventListener("input", (event) => {
    if (!(event.target instanceof HTMLInputElement)) return;
    event.target.classList.remove("is-invalid");
    event.target.removeAttribute("aria-invalid");
    showError(form);
  });
});

const loginForm = document.querySelector('[data-form="login"]');
loginForm?.addEventListener("submit", (event) => {
  event.preventDefault();
  showError(loginForm);

  const data = new FormData(loginForm);
  const email = String(data.get("email") || "").trim();
  const password = String(data.get("password") || "");
  let hasError = false;

  const invalidEmail = !/^\S+@\S+\.\S+$/.test(email);
  const invalidPassword = password.length < 6;
  markInvalid(loginForm, "email", invalidEmail);
  markInvalid(loginForm, "password", invalidPassword);
  hasError = invalidEmail || invalidPassword;

  if (hasError) {
    showError(loginForm, "Проверьте правильность заполнения полей");
    return;
  }

  try {
    login({ email, password });
    location.href = "library.html";
  } catch (error) {
    showError(loginForm, error.message);
  }
});

const registerForm = document.querySelector('[data-form="register"]');
registerForm?.addEventListener("submit", (event) => {
  event.preventDefault();
  showError(registerForm);

  const data = new FormData(registerForm);
  const name = String(data.get("name") || "").trim();
  const email = String(data.get("email") || "").trim();
  const password = String(data.get("password") || "");
  const password2 = String(data.get("password2") || "");

  const checks = {
    name: name.length < 2,
    email: !/^\S+@\S+\.\S+$/.test(email),
    password: password.length < 6,
    password2: password !== password2,
  };

  Object.entries(checks).forEach(([field, invalid]) => markInvalid(registerForm, field, invalid));

  if (Object.values(checks).some(Boolean)) {
    showError(registerForm, "Проверьте правильность заполнения полей");
    return;
  }

  try {
    register({ name, email, password });
    location.href = "library.html";
  } catch (error) {
    showError(registerForm, error.message);
  }
});
