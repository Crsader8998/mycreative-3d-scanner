import { initParticles } from "./particles.js";
import { createScene } from "./three-scene.js";
import { CursorTrail } from "./cursor-trail.js";
import { attachWatermark } from "./watermark.js";
import { initCursorSettings } from "./cursor-settings.js";
import { renderAuthBlock } from "./auth.js";

initParticles("particles-bg");

const trail = new CursorTrail("cursor-trail");
initCursorSettings(trail);

const hero3d = document.getElementById("hero-3d");
if (hero3d) {
  createScene(hero3d, { enableControls: false, autoRotate: true, cameraZ: 5.5 });

  attachWatermark(hero3d, {
    text: "MyCreative 3D Scanner",
    subtext: "© 2026 · mycreative.ru",
    logo: "assets/logo.svg",
    position: "br",
    opacity: 0.25,
    dense: false,
  });
}

renderAuthBlock("nav-auth");

const burger = document.getElementById("burger");
const nav = document.getElementById("nav");
burger?.addEventListener("click", () => {
  const isOpen = nav.classList.toggle("is-open");
  burger.classList.toggle("is-active", isOpen);
  burger.setAttribute("aria-expanded", String(isOpen));
  burger.setAttribute("aria-label", isOpen ? "Закрыть меню" : "Открыть меню");
});
nav?.querySelectorAll(".nav__link").forEach((link) =>
  link.addEventListener("click", () => {
    nav.classList.remove("is-open");
    burger?.classList.remove("is-active");
  })
);

const io = new IntersectionObserver(
  (entries) => {
    entries.forEach((e) => {
      if (e.isIntersecting) {
        e.target.classList.add("is-visible");
        io.unobserve(e.target);
      }
    });
  },
  { threshold: 0.15, rootMargin: "0px 0px -60px 0px" }
);
document.querySelectorAll(".reveal").forEach((el) => io.observe(el));