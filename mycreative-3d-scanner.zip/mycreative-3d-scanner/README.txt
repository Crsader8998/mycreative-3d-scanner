MyCreative 3D Scanner

Проект использует Node.js + Express + PostgreSQL.

Запуск: см. backend/README.md. Важно: сначала установите Node.js 20+ и PostgreSQL, затем создайте базу mycreative, выполните backend/schema.sql, настройте backend/.env и запустите npm install && npm run dev из папки backend. После запуска открывайте http://localhost:3000, а не открывайте HTML через file:// и не используйте Live Server отдельно.

Авторизация и библиотека подключены к API. Сканер по-прежнему генерирует демонстрационную геометрию, а не выполняет реальное сканирование объекта.
