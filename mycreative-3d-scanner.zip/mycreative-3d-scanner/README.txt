MyCreative 3D Scanner — финальная версия исходников

Структура:
- index.html, about.html, library.html, login.html, scanner.html
- css/ — стили
- js/ — JavaScript-модули

Папку assets/ из исходного проекта оставьте рядом без изменений.
Для корректной работы ES-модулей и importmap запускайте проект через локальный сервер (например Live Server), а не двойным кликом по HTML-файлу.
